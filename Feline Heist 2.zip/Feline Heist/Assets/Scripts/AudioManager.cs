using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Debug.Log("AudioManager activo");
        }
        else
        {
            Debug.Log("AudioManager duplicado destruido");
            Destroy(gameObject);
        }
    }

    public void PlaySound()
    {
        Debug.Log("Alo");
    }
}
